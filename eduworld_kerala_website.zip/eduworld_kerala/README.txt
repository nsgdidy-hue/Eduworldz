# EduWorld Kerala starter website

## Preview
Open `index.html` in a browser.

## Before publishing
1. Replace the temporary name "EduWorld Kerala" if desired.
2. Add your original notes, PDFs, worksheets, question papers and working download links.
3. Add a real contact email and create complete Privacy Policy and Terms pages.
4. Host the site on a web host and connect your domain.
5. Apply for Google AdSense. Approval is not guaranteed. After approval, paste the AdSense code supplied in your AdSense account into the `<head>` section and replace the two advertisement placeholders with the ad units/code Google provides.
6. Do not upload copyrighted books, notes or papers unless you have permission.

This is a static front-end starter. It does not yet include an admin panel, user accounts, file upload system or backend.
